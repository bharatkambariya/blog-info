=== Blog info ===

Contributors: bharatkambariya
Author: Bharat Kambariya
Theme URI: https://wordpress.org/themes/blog-info/
Tags: Blog
Requires at least: WordPress 4.0
Tested up to: 5.2.2
Requires PHP: 5.6
Stable tag: 2.2
Version: 2.2
Description: WordPress Theme for blog.
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: blog-info

== Description ==

Blog info is a new WordPress  theme that allows you to create  blogs and websites.The theme is well designed and does not require any other hard work to get it up and running right away. All the hard work has been done in this theme, it is clean and efficient.Theme features using the built-in WordPress Customizer, Custom Header, Custom Backgrounds, Social  Media icons and much more!. User can easily add social icons through customizer for Facebook,Google Plus,Linkedin,Twitter.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Blog-Info Theme is distributed under the terms of the GNU GPL

== Changelog ==

= 2.2 =
* Fixed Bugs and remove unnecessary code
* added backend option for social links


= 2.1 =
* Fixed bugs
* Released: May 14, 2019

= 1.0  =
* Initial release

== Resources ==
* Photo used in the screenshot is distributed under the terms of the GNU GPL
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html