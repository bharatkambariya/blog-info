        <div>
            <form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <input type="text" value="" name="s" id="s" />
                <input type="submit" id="searchsubmit" value="<?php echo esc_html__('Search', 'blog-info') ?>" />
            </form>
        </div>